import java.util.Iterator;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item>
	implements Iterable<Item>
{
	private static final String ExcpNullItem = "Cannot add a null";
	private static final String ExcpEmptyQueue = "The Queue is already empty";
	private static final String ExcpUnsupported = "Cannot remove on itertor";
	private static final double GrowthRate = 1.5;

	private Object[] base = new Object[3];
	private int head = 0, tail = 0;

	private void fit() {
		Object[] old = base;

		if (tail < base.length)
			return ;

		base = new Object[(int)(old.length * GrowthRate)];
		tail = 0;
		while (head + tail < old.length) {
			base[tail] = old[head + tail];
			tail++;
		}
		head = 0;
	}

	// construct an empty randomized queue
	public RandomizedQueue() {  }

	// is the randomized queue empty?
	public boolean isEmpty() { return base == null || size() == 0; }

	// return the number of items on the randomized queue
	public int size()        { return tail - head; }

	// add the item
	public void enqueue(Item item) {
		if (item == null)
			throw new IllegalArgumentException(ExcpNullItem);
		base[tail++] = (Object) item;
		fit();
	}

	// remove and return a random item
	public Item dequeue() {
		if (isEmpty())
			throw new java.util.NoSuchElementException(ExcpEmptyQueue);
		Item item = (Item) base[head];
		base[head++] = null;
		// StdOut.printf(" deq>> head: %d - tail: %d\n", head, tail);
		return item;
	}

	// return a random item (but do not remove it)
	public Item sample() {
		if (size() == 0)
			return null;
		// StdOut.printf(" sample>> head: %d - tail: %d\n", head, tail);
		return (Item) base[StdRandom.uniform(head, tail)];
	}

	private class QueueIterator
		implements Iterator<Item>
	{
		int[] indices = null;
		int walk = 0;
		int walk2 = head;

		public boolean hasNext() {
			if (size() == 0)
				return false;

			if (indices == null) {
				indices = new int[size()];
				indices[0] = head;
				for (int i = 0; head + i < tail; ++i) {
					int j = StdRandom.uniform(0, i + 1);
					indices[i] = indices[j];
					indices[j] = head + i;
				}
			}
			return walk < size();
		}

		public Item next()   {
			if (!hasNext())
				throw new java.util.NoSuchElementException(ExcpEmptyQueue);
			return (Item) base[indices[walk++]];
		}
		public void remove() { throw new UnsupportedOperationException(ExcpUnsupported); }
	}

	// return an independent iterator over items in random order
	public Iterator<Item> iterator() {
		return new QueueIterator();
	}

	// unit testing (required)
	public static void main(String[] args) {
		int size = (args.length == 0 ? 500 : Integer.parseInt(args[0]));

		RandomizedQueue<String> rq = new RandomizedQueue<String>();

		for (int i = 1; i < size; ++i) {
			if (rq.isEmpty())
				StdOut.printf("(** no sample in empty **) ");
			else
				StdOut.printf(rq.sample() + " ");
			try {
				rq.enqueue(Integer.toString(StdRandom.uniform(1, i + 1)));
				if (i % StdRandom.uniform(1, i + 1) == 0)
					StdOut.printf("[ remove " + rq.dequeue() + " ] ");
			} catch (java.util.NoSuchElementException e) {
				StdOut.printf("(** rm from empty **) ");
			}

		}
		StdOut.println();
		StdOut.println("\nRandomized Queue");
		for (String s : rq)
			StdOut.printf(s + " ");

		Iterator<String> itr = rq.iterator();
		int i = 0;

		StdOut.println("\n\nRandomized Queue");
		while (itr.hasNext()) {
			try {
				i++;
				StdOut.printf(itr.next() + " ");
				if (StdRandom.uniform(0, i) % 2 == 0)
					itr.remove();
			} catch(UnsupportedOperationException e) {
				continue;
			}
		}
		StdOut.println();
	}
}
